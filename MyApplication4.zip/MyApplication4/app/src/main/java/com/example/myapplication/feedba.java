package com.example.myapplication;

public class feedba {
    private String feedback;
    public feedba(){
        //empty
    }
    public feedba(String feedback)
    {
        this.feedback=feedback;
    }

    public String getFeedback() {
        return feedback;
    }
}
